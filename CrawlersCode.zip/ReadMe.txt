Crawlers Program counts the occurances of the words in the history section of the Microsoft Wikipedia page.

To Run:
	You can run the .exe application without installing any necessary packages since all the packages are self contained. I have installed
	a nuget package called Newtonsoft for JSON parsing. The .exe is in Publish Folder. 
Output:
	The output will have the top 10 most Occurance words. It will also have the performance time and the memory used for this application.
	Once the output is shown you can exit by closing the application. There is also a .png file to see the picture of the output.