Crawlers Program counts the occurances of the words in the history section of the Microsoft Wikipedia page.

To Run:
	You can run the .exe application without installing any necessary packages since all the packages are self contained. I have installed
	a nuget package called Newtonsoft for JSON parsing. The .exe is in Publish Folder. 
Output:
	There will be two user input. The first user input is the number of words to be printed and second user input is for excluded words. You can 
	enter as many words as you like that you want to exclude. To skip just hit enter.