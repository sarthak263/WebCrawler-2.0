﻿using System;
using System.Diagnostics;

namespace WikipediaCrawler
{
    internal class Program
    {
        static void Main(string[] args)
        {
    
            //instantiating the Crawler class
            Crawler c = new Crawler("Microsoft");
            c.start();
            Console.ReadLine();
        }
    }
}
